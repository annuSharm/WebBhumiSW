-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2016 at 06:32 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sm`
--

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE `enquiry` (
  `RegistrationNo` int(20) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Course` varchar(40) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `ContactNo` int(13) NOT NULL,
  `College` text NOT NULL,
  `Qualification` varchar(10) NOT NULL,
  `Semester` varchar(10) NOT NULL,
  `Address` text NOT NULL,
  `PreferredTime` time(6) NOT NULL,
  `JoiningDate` int(13) NOT NULL,
  `Refrence` text NOT NULL,
  `Feedback` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`RegistrationNo`, `Name`, `Course`, `Email`, `ContactNo`, `College`, `Qualification`, `Semester`, `Address`, `PreferredTime`, `JoiningDate`, `Refrence`, `Feedback`) VALUES
(49, 'niru', 'java', 's@s.com', 2147483647, 'HR', 'B.E', 'completed', 'Geeta Bhawan', '11:00:00.000000', 12, 'Herself', 'WEb Bhumi'),
(50, 'nirupama', 'java', 's@s.com', 2147483647, 'HR', 'B.E', 'completed', 'Geeta Bhawan', '11:00:00.000000', 12, 'Herself', 'WEb Bhumi'),
(51, 'nirupama', 'C&C++', 'niru@webbhumi.com', 29817453, 'owner', 'B.E in IT', 'job', 'Geeta Bhawan Sq.', '10:00:00.000000', 12, 'Her Dream', 'WEb Bhumi must be best'),
(52, 'Aruna', 'C&C++', 'aruna@webbhumi.com', 986874287, 'doveloper', 'MCA', '3rd', 'coral palace', '09:00:00.000000', 7, 'Abhishek', 'This is the best '),
(54, 'niru', '', '', 0, '', '', '', '', '00:00:00.000000', 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `email` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`email`, `password`) VALUES
('', ''),
('arunasharma2723@gmail.com', 'asd');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `RegistrationNo` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `ContactNo` int(40) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Address` text NOT NULL,
  `Course` varchar(100) NOT NULL,
  `Fees` int(10) NOT NULL,
  `Installment1` int(10) NOT NULL,
  `submissionDate1` date NOT NULL,
  `Installment2` int(11) NOT NULL,
  `submissionDate2` date NOT NULL,
  `College` text,
  `Qualification` text NOT NULL,
  `Semester` varchar(10) NOT NULL,
  `Refrence` text,
  `Feedback` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`RegistrationNo`, `Name`, `ContactNo`, `Email`, `Address`, `Course`, `Fees`, `Installment1`, `submissionDate1`, `Installment2`, `submissionDate2`, `College`, `Qualification`, `Semester`, `Refrence`, `Feedback`) VALUES
(0, 'ghf', 24, 'aruna@webbhumi.com', 'vhgdhnh', 'nvgtc h', 61, 55, '0000-00-00', 59, '0000-00-00', NULL, '', '', NULL, ''),
(0, 'ghf', 24, 'aruna@webbhumi.com', 'vhgdhnh', 'nvgtc h', 61, 55, '0000-00-00', 59, '0000-00-00', NULL, '', '', NULL, ''),
(0, 'ghf', 24, 'aruna@webbhumi.com', 'vhgdhnh', 'nvgtc h', 61, 55, '0000-00-00', 59, '0000-00-00', NULL, '', '', NULL, ''),
(0, 'ghf', 24, 'aruna@webbhumi.com', 'vhgdhnh', 'nvgtc h', 61, 55, '0000-00-00', 59, '0000-00-00', NULL, '', '', NULL, ''),
(0, 'sd', 0, 'jtyfhn@gmail.com', 'buyfdcjn', 'jgfdyrtgfvbc', 0, 0, '0000-00-00', 0, '0000-00-00', 'vytrfhc', 'vghjfcn', 'vtfcjm', 'tfhhm', 'ytghjhu'),
(0, 'ojisahcsak', 24333, 'bsjxfxv@gmail.com', 'f6cufscsv', 'hjtjwysg', 0, 0, '0000-00-00', 0, '0000-00-00', 'guegfcjchv n', 'ky7cjg', 'jkysjgcbmk', 'DXA', 'bjysatxfjgmnx,k'),
(0, 'ojisahcsak', 24333, 'bsjxfxv@gmail.com', 'f6cufscsv', 'hjtjwysg', 0, 0, '0000-00-00', 0, '0000-00-00', 'guegfcjchv n', 'ky7cjg', 'jkysjgcbmk', 'DXA', 'bjysatxfjgmnx,k'),
(0, '', 0, '', '', '', 0, 0, '0000-00-00', 0, '0000-00-00', '', 'hyrfn', 'mcstu6yjgv', '', ''),
(0, 'niru', 0, 's@s.com', 'vhgdhnh', 'afhhhha', 978, 131, '0000-00-00', 24, '0000-00-00', 'cgrytfcxt4', 'hyrfn', 'vhyrhfvjut', 'fhbfd', 'fgdfbfcvnghn'),
(0, 'niru', 111111, 's@s.com', 'vhgdhnh', 'afhhhha', 978, 131, '0000-00-00', 24, '0000-00-00', 'cgrytfcxt4', 'hyrfn', 'vhyrhfvjut', 'fhbfd', 'fgdfbfcvnghn');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `enquiry`
--
ALTER TABLE `enquiry`
  ADD PRIMARY KEY (`RegistrationNo`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `enquiry`
--
ALTER TABLE `enquiry`
  MODIFY `RegistrationNo` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
