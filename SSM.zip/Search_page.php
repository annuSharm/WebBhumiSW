<!DOCTYPE HTML>
<html>  
<body>

<p>You Want to Search: <?php echo $_POST["sr"]?></p>
<p>Search Name: <?php echo $_POST["name"]?></p>
<p>Search Course: <?php echo $_POST["course"]?></p>

<?php
$servername = "localhost";
$username = "root";
$password = "boot";

$search=$_POST["sr"];
$name=$_POST["name"];
$course=$_POST["course"];

// Create connection
$conn = new mysqli($servername, $username, $password, "sm");
//$sql="SELECT * FROM `enquiry` OR `Registration` WHERE (RegistrationNo='$search' OR Name='$search' OR Course='$search' OR Email='$search' OR ContactNo='$search' OR College='$search' OR Qualification='$search' OR Semester='$search' OR Address='$search' OR PreferredTime='$search' OR JoiningDate='$search' OR Refrence='$search' OR Feedback='$search')";
//$sql="SELECT * FROM `enquiry` OR `Registration` WHERE LIKE Name='%$name%'";
//$sql="SELECT * FROM `enquiry` WHERE City IN ( Course='$course')";
//$sql="SELECT * FROM `Registration` WHERE Course IN ( Course='$course')";
$sql="SELECT * FROM `Registration` WHERE (RegistrationNo='niru' OR Name='niru' OR Course='niru' OR Email='niru' OR ContactNo='niru' OR College='niru' OR Qualification='niru' OR Semester='niru' OR Address='niru' OR Refrence='niru' OR Feedback='niru')";
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";

if ($conn->query($sql) === TRUE) {
   // echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?> 

</body>
</html>